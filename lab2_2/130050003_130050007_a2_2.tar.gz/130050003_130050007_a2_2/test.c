struct S
{
    int a;
    float b;
};

int A(){
    int x;
    return &x;
}

int main()
{
    float f1,f2,f3;
    float fa[3];
    int ia[3];
    int i1,i2;
    struct S x;
    for(x;x;x);
    i1 = f1 + f2;
    f3 = f1 / i2;
    f1 = i1 * x.a;
    i1 = fa[0] + ia[5];
}