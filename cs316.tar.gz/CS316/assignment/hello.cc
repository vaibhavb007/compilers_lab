void fn(int a, int b){
	a=3;
	b=4;
	return;
}